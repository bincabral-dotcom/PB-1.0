package com.photobatch.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); enableEdgeToEdge(); setContent { PhotoBatchApp() } }
}

private data class Edits(
    val brightness: Float = 0f, val contrast: Float = 0f, val exposure: Float = 0f,
    val highlights: Float = 0f, val shadows: Float = 0f, val whites: Float = 0f, val blacks: Float = 0f,
    val temperature: Float = 0f, val tint: Float = 0f, val vibrance: Float = 0f, val saturation: Float = 0f
)

private val dark = Color(0xFF101512); private val panel = Color(0xFF1A211C); private val mint = Color(0xFF9EF2B3)

@Composable private fun PhotoBatchApp() {
    val context = LocalContext.current
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var selected by remember { mutableIntStateOf(0) }
    var edits by remember { mutableStateOf(Edits()) }
    var exporting by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(30)) { picked ->
        if (picked.isNotEmpty()) { photos = picked; selected = 0; notice = "${picked.size} foto(s) pronta(s) para editar" }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = mint, surface = panel, background = dark)) {
        Scaffold(containerColor = dark, snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }) { inset ->
            Column(Modifier.fillMaxSize().padding(inset).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(mint), contentAlignment = Alignment.Center) { Icon(Icons.Default.Collections, null, tint = dark) }
                    Spacer(Modifier.width(10.dp)); Column { Text("PHOTOBATCH", fontWeight = FontWeight.Black); Text("Edite uma vez. Aplique em todas.", style = MaterialTheme.typography.labelSmall, color = Color.LightGray) }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(4.dp)); Text("Fotos") }
                }
                if (photos.isEmpty()) EmptyState { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
                else Editor(photos, selected, { selected = it }, edits, { edits = it }, exporting, {
                    exporting = true
                    scope.launch { val result = withContext(Dispatchers.Default) { exportAll(context, photos, edits) }; exporting = false; notice = result }
                })
                notice?.let { Text(it, color = mint, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(vertical = 6.dp)) }
            }
        }
    }
}

@Composable private fun EmptyState(select: () -> Unit) = Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
        Icon(Icons.Default.PhotoLibrary, null, tint = mint, modifier = Modifier.size(68.dp)); Spacer(Modifier.height(16.dp))
        Text("Suas fotos, seu estilo", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Selecione uma ou mais fotos para ajustar e exportar em lote.", color = Color.LightGray, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(20.dp)); Button(onClick = select) { Icon(Icons.Default.PhotoLibrary, null); Spacer(Modifier.width(8.dp)); Text("Selecionar fotos") }
    }
}

@Composable private fun Editor(photos: List<Uri>, selected: Int, choose: (Int) -> Unit, edits: Edits, change: (Edits) -> Unit, exporting: Boolean, export: () -> Unit) {
    val context = LocalContext.current
    val original = remember(photos[selected]) { loadBitmap(context, photos[selected], 1400) }
    val preview = remember(original, edits) { original?.let { ImageEngine.apply(it, edits) } }
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxWidth().height(230.dp).padding(top = 8.dp).clip(RoundedCornerShape(18.dp)).background(panel), contentAlignment = Alignment.Center) {
            if (preview != null) Image(preview.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        LazyRow(contentPadding = PaddingValues(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            itemsIndexed(photos) { index, uri -> val thumb = remember(uri) { loadBitmap(context, uri, 160) }; Box(Modifier.size(58.dp).clip(RoundedCornerShape(10.dp)).background(if (index == selected) mint else panel).clickable { choose(index) }.padding(2.dp)) { if (thumb != null) Image(thumb.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) } }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { change(autoEdits(original)) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.AutoFixHigh, null); Spacer(Modifier.width(6.dp)); Text("Automático") }
            Button(onClick = export, enabled = !exporting, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(6.dp)); Text(if (exporting) "Exportando..." else "Exportar lote") }
        }
        Text("Ajustes", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 10.dp)) {
            SliderGroup("Luz") { Adjust("Brilho", edits.brightness, -1f..1f) { change(edits.copy(brightness = it)) }; Adjust("Contraste", edits.contrast, -1f..1f) { change(edits.copy(contrast = it)) }; Adjust("Exposição", edits.exposure, -2f..2f) { change(edits.copy(exposure = it)) }; Adjust("Realces", edits.highlights, -1f..1f) { change(edits.copy(highlights = it)) }; Adjust("Sombras", edits.shadows, -1f..1f) { change(edits.copy(shadows = it)) }; Adjust("Brancos", edits.whites, -1f..1f) { change(edits.copy(whites = it)) }; Adjust("Pretos", edits.blacks, -1f..1f) { change(edits.copy(blacks = it)) } }
            SliderGroup("Cor") { Adjust("Temperatura", edits.temperature, -1f..1f) { change(edits.copy(temperature = it)) }; Adjust("Matiz", edits.tint, -1f..1f) { change(edits.copy(tint = it)) }; Adjust("Vibração", edits.vibrance, -1f..1f) { change(edits.copy(vibrance = it)) }; Adjust("Saturação", edits.saturation, -1f..1f) { change(edits.copy(saturation = it)) } }
        }
    }
}

@Composable private fun SliderGroup(title: String, body: @Composable ColumnScope.() -> Unit) { Text(title, color = mint, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Column(content = body) }
@Composable private fun Adjust(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) { Row(verticalAlignment = Alignment.CenterVertically) { Text(label, modifier = Modifier.width(105.dp), style = MaterialTheme.typography.labelMedium); Slider(value = value, onValueChange = onChange, modifier = Modifier.weight(1f), valueRange = range); Text("%+.0f".format(value * 100), Modifier.width(44.dp), style = MaterialTheme.typography.labelSmall) } }

private fun loadBitmap(context: Context, uri: Uri, maxSide: Int): Bitmap? = try { context.contentResolver.openInputStream(uri)?.use { input -> val raw = BitmapFactory.decodeStream(input) }?.let { b -> val scale = min(1f, maxSide.toFloat() / max(b.width, b.height)); if (scale == 1f) b else Bitmap.createScaledBitmap(b, (b.width * scale).toInt(), (b.height * scale).toInt(), true) } } catch (_: Exception) { null }
private fun autoEdits(b: Bitmap?): Edits { if (b == null) return Edits(); val p = IntArray(b.width * b.height); b.getPixels(p, 0, b.width, 0, 0, b.width, b.height); var total = 0.0; for (v in p) total += ((v shr 16 and 255) + (v shr 8 and 255) + (v and 255)) / 765.0; val mean = (total / p.size).toFloat(); return Edits(exposure = ((0.52f - mean) * 1.5f).coerceIn(-.65f, .65f), contrast = .12f, shadows = .12f, highlights = -.10f, vibrance = .10f) }

private object ImageEngine {
    fun apply(source: Bitmap, e: Edits): Bitmap { val w = source.width; val h = source.height; val px = IntArray(w*h); source.getPixels(px,0,w,0,0,w,h); val exp = 2.0.pow(e.exposure.toDouble()).toFloat(); for(i in px.indices){ val a=px[i] ushr 24; var r=(px[i] shr 16 and 255)/255f; var g=(px[i] shr 8 and 255)/255f; var b=(px[i] and 255)/255f; r*=exp;g*=exp;b*=exp; val l=(r+g+b)/3f; val lift=if(l<.5f) e.shadows*(.5f-l)*2f else e.highlights*(l-.5f)*-2f; r+=lift;g+=lift;b+=lift; val wb=if(l>.72f)e.whites*(l-.72f)*3.5f else 0f; val bk=if(l<.28f)e.blacks*(.28f-l)*-3.5f else 0f; r+=wb+bk+e.brightness*.18f;g+=wb+bk+e.brightness*.18f;b+=wb+bk+e.brightness*.18f; r=(r-.5f)*(1+e.contrast)+.5f+e.temperature*.13f; g=(g-.5f)*(1+e.contrast)+.5f+e.tint*.09f; b=(b-.5f)*(1+e.contrast)+.5f-e.temperature*.13f; val gray=r*.299f+g*.587f+b*.114f; val maxc=max(r,max(g,b)); val minc=min(r,min(g,b)); val sat=maxc-minc; val factor=1+e.saturation+e.vibrance*(1-sat); r=gray+(r-gray)*factor;g=gray+(g-gray)*factor;b=gray+(b-gray)*factor; px[i]=(a shl 24) or (c(r) shl 16) or (c(g) shl 8) or c(b) }; return Bitmap.createBitmap(px,w,h,Bitmap.Config.ARGB_8888) }
    private fun c(v:Float)= (v.coerceIn(0f,1f)*255).roundToInt()
}
private fun exportAll(context: Context, photos: List<Uri>, edits: Edits): String { var done=0; photos.forEachIndexed { i, uri -> val b=loadBitmap(context,uri,2048) ?: return@forEachIndexed; val out=ImageEngine.apply(b,edits); val values=ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME,"PHOTOBATCH_${System.currentTimeMillis()}_${i+1}.jpg"); put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg"); put(MediaStore.Images.Media.RELATIVE_PATH,"DCIM/PHOTOBATCH") }; val target=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values); try { target?.let { context.contentResolver.openOutputStream(it)?.use { stream -> out.compress(Bitmap.CompressFormat.JPEG,95,stream); done++ } } } catch (_:Exception){ target?.let{context.contentResolver.delete(it,null,null)} } }; return if(done==photos.size) "$done foto(s) salva(s) em DCIM/PHOTOBATCH" else "$done de ${photos.size} foto(s) foram salvas" }
