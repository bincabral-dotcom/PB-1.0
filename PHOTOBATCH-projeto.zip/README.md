# PHOTOBATCH

Editor de fotos Android com ajustes de luz e cor, ajuste automático e aplicação em lote.

## Compilar no GitHub

Envie o conteúdo deste projeto para um repositório. Depois, crie o arquivo `.github/workflows/android.yml` usando o arquivo `photobatch-android.yml` entregue ao lado do ZIP. Em **Actions**, rode o workflow **Build Android APK** e baixe o artefato `PHOTOBATCH-debug-apk`.

## Recursos

- Seleção de várias fotos com miniaturas.
- Brilho, contraste, exposição, realces, sombras, brancos, pretos, temperatura, matiz, vibração e saturação.
- Ajuste automático baseado na leitura da imagem.
- Aplicação da configuração atual em todas as fotos selecionadas.
- Exportação para `DCIM/PHOTOBATCH`.

O editor trabalha localmente no aparelho; nenhuma foto é enviada para servidores.
